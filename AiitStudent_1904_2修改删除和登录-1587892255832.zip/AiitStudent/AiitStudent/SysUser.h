#pragma once

// ϵͳ�û�
class SysUser
{
public:
	SysUser();
	~SysUser();

	string uid;
	string pwd;
};


#include "stdafx.h"
#include "SysUser.h"


SysUser::SysUser()
{
}


SysUser::~SysUser()
{
}

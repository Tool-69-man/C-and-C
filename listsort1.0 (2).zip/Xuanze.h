#pragma once
#include"sort.h"
class Xuanze:public Sort
{
public:
	void sortlistUp();
	void sortlistDown();

	void sort();
};


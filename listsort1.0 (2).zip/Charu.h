#pragma once
#include"sort.h"
class Charu:public Sort
{
public:

	void sortlistUp();
	void sortlistDown();

	void sort();
};


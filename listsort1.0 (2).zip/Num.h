#pragma once
#include"allhead.h"
class Num
{
public:
	int num;
	void show();
};


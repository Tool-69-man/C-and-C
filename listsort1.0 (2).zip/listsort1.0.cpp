﻿#include"Maop.h"
#include"Kuaisu.h"
#include"Charu.h"
int main() {
	Maop m1;
	Charu c1;

	
	return 0;
}
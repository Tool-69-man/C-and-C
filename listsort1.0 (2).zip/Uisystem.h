#pragma once
#include"allhead.h"
class Uisystem
{
public:
	bool choice();
	Uisystem();
};


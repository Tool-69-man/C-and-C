#pragma once
#include"sort.h"
class Maop:public Sort
{
public:
	void sortlistUp();
	void sortlistDown();

	void sort();
	

};


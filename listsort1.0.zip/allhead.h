#pragma once
#include<iostream>
#include<string>
#include<ctype.h>
using namespace std;
#define maxnum 5 
#define PA  system("pause")
#define CLS system("cls")
#define PC  PA;CLS
#define br cout<<endl 
#define li cout << "=================================================================================" << endl
#pragma once
// ѧ����
class Student
{
public:
	Student();
	~Student();

	string name;
	string stuNO;// ѧ��
	int age;

	void show();
};


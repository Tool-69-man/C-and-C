#pragma once
class resule
{
};


#pragma once
#include"��ͷ.h"
class Space
{
public:
	int count3;
};


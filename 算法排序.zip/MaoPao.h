#pragma once
#include"sort.h"
class MaoPao
{
public:
	/*void sortlistUp();
	void sortlistDown(Sort &a);*/
	MaoPao();
};


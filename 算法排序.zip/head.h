#pragma once
#include<iostream>
#include<string>
using namespace std;
#define maxnum 5 
#define PA  system("pause")
#define CLS system("cls")
#define PC  PA;CLS
#define br cout<<endl 
#include"UImap.h"

int main() {
	
	Sort s1;
	MaoPao a1;
	
	s1.scanfList();
	s1.show();
	s1.goSort();
	//a1.sortlistDown(s1);
	return 0;
}
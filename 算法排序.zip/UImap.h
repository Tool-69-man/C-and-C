#pragma once
#include"sort.h"
class UImap
{
public:
};


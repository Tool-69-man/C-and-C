#include "MaoPao.h"

//void MaoPao::sortlistDown(Sort &a)
//{
//	int i = 0;
//	int j = 0;
//
//	for (i = 0; i < a.count; i++)
//	{
//		for (j = i; j <a. count - i - 1; j++)
//		{
//			if (a.listnum[j].num > a.listnum[j + 1].num) {
//				int temp = 0;
//				temp = a.listnum[j + 1].num;
//				a.listnum[j + 1].num = a.listnum[j].num;
//				a.listnum[j].num = temp;
//			}
//		}
//	}
//	cout << "���չʾ" << endl;
//	a.show();
//
//}

MaoPao::MaoPao()
{
}

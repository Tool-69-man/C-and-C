#pragma once
#include"head.h"
class Num
{
public:
	int num;
	void show();
};


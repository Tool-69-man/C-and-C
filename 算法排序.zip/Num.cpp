#include "Num.h"

void Num::show()
{
	cout << num<<endl;
}

#include"tool.h"
class Child
{
public:
	string name;
	int age;
	string grade;

	void show();
	Child();
	Child(string name ,int age,string grade );
	~Child();


private:

};


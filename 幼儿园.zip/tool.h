#pragma once
#include<iostream>
#include<string>
using namespace std;
#define MAX 20
#define PA system("pause")
#define CLS system("cls")
#define PC PA;CLS